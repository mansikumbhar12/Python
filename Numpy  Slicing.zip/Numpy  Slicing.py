Python 3.12.2 (tags/v3.12.2:6abddd9, Feb  6 2024, 21:26:36) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> #Assignment:
... #1. Write a NumPy program to create an array of 10 zeros, 10 ones, and 10 fives.
>>> import numpy as np
>>> zeros_array = np.zeros(10)
>>> ones_array = np.ones(10)
>>> fives_array = np.full(10, 5)
>>> print("Array of 10 zeros:", zeros_array)
Array of 10 zeros: [0. 0. 0. 0. 0. 0. 0. 0. 0. 0.]
>>> print("Array of 10 ones:", ones_array)
Array of 10 ones: [1. 1. 1. 1. 1. 1. 1. 1. 1. 1.]
>>> print("Array of 10 fives:", fives_array)
Array of 10 fives: [5 5 5 5 5 5 5 5 5 5]
>>> 
>>> #2. Write a NumPy program to create a 3x3 matrix with values ranging from 2 to 10.
>>> matrix_3x3 = np.arange(2, 11).reshape(3, 3)
>>> print("\n3x3 matrix with values from 2 to 10:\n", matrix_3x3)

3x3 matrix with values from 2 to 10:
 [[ 2  3  4]
 [ 5  6  7]
 [ 8  9 10]]
>>> 
>>> #3. Write a NumPy program to create an array with values ranging from 12 to 38.
...  
>>> array_12_to_38 = np.arange(12, 39)
>>> print("\nArray with values from 12 to 38:", array_12_to_38)

Array with values from 12 to 38: [12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
 36 37 38]
>>> 
>>> #4. Write a NumPy program to convert a list and tuple into arrays.
... # Input: my_list = [1, 2, 3, 4, 5, 6, 7, 8]
... # Input: my_tuple = ([8, 4, 6], [1, 2, 3])
>>> my_list = [1, 2, 3, 4, 5, 6, 7, 8]
>>> my_tuple = ([8, 4, 6], [1, 2, 3])
>>> array_from_list = np.array(my_list)
>>> array_from_tuple = np.array(my_tuple)
>>> print("\nArray from list:", array_from_list)

Array from list: [1 2 3 4 5 6 7 8]
>>> print("Array from tuple:\n", array_from_tuple)
Array from tuple:
 [[8 4 6]
 [1 2 3]]
